#include "SceneChange.h"

bool SceneChange::Change(int nextscenenum, std::string nextmapname, std::string oldmapname)
{
	return false;
}
